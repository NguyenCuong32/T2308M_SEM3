﻿namespace EduProjectDemo.Models
{
    public class StudentReport
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public int Age { get; set; }
        public string Address { get; set; }
        public int CourseId { get; set; }
        public string CourseName { get; set; }
        public string ClassName { get; set; }
    }
}
